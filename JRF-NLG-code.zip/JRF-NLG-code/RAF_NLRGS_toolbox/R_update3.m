function   R    =   R_update3(MSI_BS, HSI_2D,R)

[~,n] = size (R);
D = zeros(n,n-1);
for i = 1:n-1
    D(i,i)   = -1;
    D(i+1,i) = 1;
end

lambda = 1e-7;
mu=1e-4;
V=R;
G=zeros(size(R));
DDT = D*D';
G1=HSI_2D*HSI_2D';
G2=MSI_BS*HSI_2D';  
for i=1:100
    R=(G2+mu*V-G/2)/(lambda*DDT+G1+mu*eye(size(HSI_2D,1)));
    V=R+G/(2*mu);
    V(V<0)=0;
    G=G+2*mu*(R-V);
%     mu=mu*1.1;
% norm(R-V)
end
% a1=norm(R1*HSI_2D-MSI_BS,'fro');
% a2=norm(V*HSI_2D-MSI_BS,'fro');
% % norm(R1-V)/norm(R)
%   R;