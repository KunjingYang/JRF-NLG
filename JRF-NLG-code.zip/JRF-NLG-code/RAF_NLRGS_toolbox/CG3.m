function [ W ] = CG3(  FTF1,FTF2,Ck,H,W0,mu,T )
% optimize the dictionaries via Conjugate gradient 
 maxIter = 150;
 
 r0 = T'*T*W0*Ck*FTF2*Ck'+W0*Ck*FTF1*Ck'+mu*W0-H;  
 p0 = -r0;
 for i = 1:maxIter
     Ap = T'*T*p0*Ck*FTF2*Ck'+p0*Ck*FTF1*Ck'+mu*p0; % AP
     pp1 = p0(:)'*Ap(:);

     a = (r0(:)')*r0(:)/pp1;
     W = W0+a*p0;
     r1 = r0+a*Ap;
     b1 = (r1(:)'*r1(:))/(r0(:)'*r0(:));
     p1 = -r1+b1*p0;
    
     p0 = p1;
     r0 = r1;
     W0 = W;
     if norm(r0)<=0.01
         break;
     end
 end
 
