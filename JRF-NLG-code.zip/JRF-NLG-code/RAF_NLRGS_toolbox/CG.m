function P = CG( P0,A,MSI3,cg_iter )
% optimize the dictionaries via Conjugate gradient 
H = MSI3*A';
 r0 = P0*(A*A')-H;  
 p0 = -r0;
 for i = 1:cg_iter
     Ap = p0*(A*A'); % AP
     pp1 = p0(:)'*Ap(:);

     a = (r0(:)')*r0(:)/pp1;
     P = P0+a*p0;
     r1 = r0+a*Ap;
     b1 = (r1(:)'*r1(:))/(r0(:)'*r0(:));
     p1 = -r1+b1*p0;
    
     p0 = p1;
     r0 = r1;
     P0=P;
     if norm(r0)<=0.001
         break;
     end
 end
 
 
