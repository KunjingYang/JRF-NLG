function   R    =   R_update(MSI3, A,R,mu)


mu=1e-4;
V=R;
G=zeros(size(R));
AA = A*A';

for i=1:50
    R=(MSI3*A'+mu*V-G/2)/(AA+mu*eye(size(AA)));
    V=R+G/(2*mu);
    V(V<0)=0;
    G=G+2*mu*(R-V);
%     mu=mu*1.1;
% norm(R-V)
end
% a1=norm(R1*HSI_2D-MSI_BS,'fro');
% a2=norm(V*HSI_2D-MSI_BS,'fro');
% % norm(R1-V)/norm(R)
%   R;