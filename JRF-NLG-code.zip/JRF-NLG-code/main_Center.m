clear; %clc ;

% addpath
addpath RAF_NLRGS_toolbox;
addpath data ;
addpath results ;

load('.\data\R.mat');

true_image   =   load('.\data\Pavia_Center.mat');
true_image   =   true_image.pavia;
true_image   =   true_image(1:256,1:256,10:end);
true_image   =   double(true_image); 
true_image   =   true_image/max(true_image(:));
par.true_image = true_image ;
[M,N,L]      =   size(true_image);

sf = 4;  s0 = 1;  sz = [M N];
psf            =    fspecial('gaussian',7,2);
par.fft_B      =    psf2otf(psf,sz);
par.fft_BT     =    conj(par.fft_B);
par.H          =    @(z)H_z(z, par.fft_B, sf, sz,s0 );
par.HT         =    @(y)HT_y(y, par.fft_BT, sf, sz,s0);

F=R; F = F(:,6:end-5);
for band = 1:size(F,1)
        div = sum(F(band,:));
        for i = 1:size(F,2)
            F(band,i) = F(band,i)/div;
        end
end
S_bar = hyperConvert2D(true_image);
hyper= par.H(S_bar); % ģ��+������ ��BS
MSI = hyperConvert3D((F*S_bar), M, N);
HSI =hyperConvert3D(hyper,M/sf, N/sf );

unregisHsi = HSI;
%% Load hsi and msi
 
% make transform to hsi
% unregisHsi = imrotate(unregisHsi,10);         % rotation

% unregisHsi = imtranslate(unregisHsi,[5, 5]); % translation

unregisHsi = imresize(unregisHsi,1.1);     % scaling

% unregisHsi = barrel_distortion (unregisHsi, 1e-3);  % barrel_distortion  

% tran_matrix=[1 0.5 0; 0.5 1 0; 0 0 1];        % flip
% tform=maketform("affine",tran_matrix);
% unregisHsi=imtransform(unregisHsi,tform);

% hsi to a batch of grayscale image
unregisHsi = unregisHsi(1:64,1:64,:); 
[~,~,spec] = size(unregisHsi);
str = '.\data\HSI\';
for band = 1:spec   % mat to bmp
    if band < 10
        name = sprintf('00%d.bmp',band);
        imwrite(unregisHsi(:,:,band),[str,name] );
    else
        name = sprintf('0%d.bmp',band);
        imwrite(unregisHsi(:,:,band),[str,name] );
    end
end
par.unregisHsi = unregisHsi;

%% define images' path

currentPath = cd;

% input path
imagePath = fullfile(currentPath,'data') ;
pointPath = fullfile(currentPath,'data') ; % path to files containing initial feature coordinates
userName = 'HSI' ;

% output path
destRoot = fullfile(currentPath,'results') ;
destDir = fullfile(destRoot,userName) ;
if ~exist(destDir,'dir')
    mkdir(destRoot,userName) ;
end

%% define parameters

% display flag
rafpara.DISPLAY = 0 ;

% save flag
rafpara.saveStart = 1 ;
rafpara.saveEnd = 1 ;
rafpara.saveIntermedia = 0 ;

rafpara.canonicalImageSize = [ 64 64  ];     
rafpara.canonicalCoords = [ 0.5   44 ; 17 17  ]; 

% parametric tranformation model
rafpara.transformType = 'SIMILARITY'; 
% one of 'TRANSLATION', 'SIMILARITY', 'AFFINE','HOMOGRAPHY'

rafpara.numScales = 1 ; % if numScales > 1, we use multiscales

rafpara.isblind = 0;
if rafpara.isblind == 1
    rafpara.step = 1;
else
    rafpara.step = 2;
end

%% Generate HSI and MSI
sf = 4;   s0 = 1;   sz = [M N];  par.sf=sf;
par.psf        =    fspecial('gaussian',7,2);
par.fft_B      =    psf2otf(par.psf,sz);
par.fft_BT     =    conj(par.fft_B);
par.H          =    @(z)H_z(z, par.fft_B, sf, sz,s0 );
par.HT         =    @(y)HT_y(y, par.fft_BT, sf, sz,s0);

R = load('.\data\R.mat');
R = R.R; 
F = R(:,6:end-5); 
for band = 1:size(F,1)
        div = sum(F(band,:));
        for i = 1:size(F,2)
            F(band,i) = F(band,i)/div;
        end
end
par.R = F;  % Spectral dowmsamping operator


%% Get training images

% get initial transformation
transformationInit = 'SIMILARITY'; 
[fileNames, transformations, numImages] = get_training_images( imagePath, pointPath, userName, rafpara.canonicalCoords, transformationInit) ;

%% JAF
rafpara.subspaceDim  = 4;  rafpara.tao = 20;   
rafpara.mu1 = 10; rafpara.mu2 = 10;   rafpara.iscal = 1;
[D, A, xi,t1, Z, kappa ] = RAF_outer(fileNames, transformations, numImages, rafpara, destDir, MSI, par);

%% NLG
load('Registered_HSI.mat');  Registered_HSI = MN_3D;
if  rafpara.isblind == 1
    [R,B]          =    Kernal_estimation(Registered_HSI, MSI,7);
    par.psf        =    B;
    par.fft_B      =    psf2otf(par.psf,sz); % psf -> blur kernel
    par.fft_BT     =    conj(par.fft_B);
    par.H          =    @(z)H_z(z, par.fft_B, sf, sz,s0 );
    par.HT         =    @(y)HT_y(y, par.fft_BT, sf, sz,s0); 
    par.R = R;
    
    nlrgs.K=100;  nlrgs.patchsize=8;  nlrgs.p1=2;  nlrgs.p2=0; nlrgs.tao=15; nlrgs.mu=1e-5; m=2;
    nlrgs.alpha=1e-3; nlrgs.beta=1e-5; nlrgs.mul=1e-3; nlrgs.mue=1e-3; nlrgs.theta=8; n=2;
else
    nlrgs.K=200;  nlrgs.patchsize=8;  nlrgs.p1=3;  nlrgs.p2=70; nlrgs.tao=10; nlrgs.mu=1e-5; m=2;
    nlrgs.alpha=2e-3; nlrgs.beta=2e-3; nlrgs.mul=5e-3; nlrgs.mue=5e-3; nlrgs.theta=7; n=2;
end

[X, t2] = NLRGS_Fus(Registered_HSI, MSI, par.R, sf, nlrgs, par, m,n,rafpara);

%% Result of RAF-NLRGS
[PSNR,RMSE,ERGAS,SAM, ~,SSIM,~,~] = quality_assessment(double(im2uint8(par.true_image)),double(im2uint8(X)),0,1/sf);
the_index_of_fused_image = ["PSNR" "SSIM" "ERGAS" "SAM"  "RMSE" "time"; PSNR SSIM ERGAS SAM RMSE t1+t2]


[PSNR,RMSE,ERGAS,SAM, ~,SSIM,~,~] = quality_assessment(double(im2uint8(HSI)),double(im2uint8(Registered_HSI)),0,1/sf);
the_index_of_registered_hsi = ["PSNR" "SSIM" "ERGAS" "SAM"  "RMSE"; PSNR SSIM ERGAS SAM RMSE]

